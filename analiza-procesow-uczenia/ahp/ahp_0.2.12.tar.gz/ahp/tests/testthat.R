library(testthat)

test_check("ahp")
#devtools::test()