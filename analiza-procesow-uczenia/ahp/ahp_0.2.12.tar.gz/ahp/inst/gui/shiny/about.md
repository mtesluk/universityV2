---
title: "About"
author: "Christoph Glur"
date: "12.1.2016"
output: html_document
---

## AHP Shiny App

Authors: [Christoph Glur](http://ipub.com/about/)

More information about AHP and the R package can be found here: http://ipub.com/tag/ahp/

The github repository is here: http://github.com/gluc/ahp/

Bug reports directly to http://github.com/gluc/ahp/issues

Please star the package on github if you like it.

This package is published under the GPL3 license.
